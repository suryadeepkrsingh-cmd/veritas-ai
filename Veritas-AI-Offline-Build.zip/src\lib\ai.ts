export interface VerificationResult {
  verdict: 'True' | 'False' | 'Unverified';
  confidence: number;
  explanation: string;
  backendOffline?: boolean;
  sentiment: 'Neutral' | 'Biased' | 'Inflammatory';
  riskLevel: 'Low' | 'Medium' | 'High';
  scoreBreakdown: {
    sourceReliability: number;
    logicalConsistency: number;
    factualAlignment: number;
  };
  redFlags: string[];
  relatedClaims: { claim: string; verdict: string; url: string }[];
  sources: { name: string; url: string }[];
}

export interface UrlPreviewResult {
  url: string;
  title: string;
  excerpt: string;
  domain: string;
  scraped: boolean;
}

export interface FeedbackPayload {
  claim: string;
  verdict: string;
  confidence: number;
  helpful?: boolean;
  name: string;
  email: string;
  message: string;
}

export async function verifyClaim(input: string): Promise<VerificationResult> {
  try {
    const response = await fetch('http://127.0.0.1:3001/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ claim: input }),
    });

    if (!response.ok) {
      throw new Error('Backend verification failed');
    }

    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    return {
      verdict: 'Unverified',
      confidence: 0,
      explanation: 'Backend offline. Start the verification server with "npm run server" and try again.',
      backendOffline: true,
      sentiment: 'Neutral',
      riskLevel: 'Low',
      scoreBreakdown: {
        sourceReliability: 0,
        logicalConsistency: 0,
        factualAlignment: 0,
      },
      redFlags: [],
      relatedClaims: [],
      sources: [],
    };
  }
}

export async function fetchUrlPreview(url: string): Promise<UrlPreviewResult> {
  const response = await fetch('http://127.0.0.1:3001/api/scrape-preview', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  });

  if (!response.ok) {
    throw new Error('Failed to fetch URL preview');
  }

  return response.json();
}

export async function submitFeedback(payload: FeedbackPayload): Promise<{ ok: boolean }> {
  const response = await fetch('http://127.0.0.1:3001/api/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error('Failed to submit feedback');
  }

  return response.json();
}
